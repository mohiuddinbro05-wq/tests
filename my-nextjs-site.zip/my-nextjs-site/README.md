# my-nextjs-site

This is a starter Next.js project created for you.

Commands:

- `npm install`
- `npm run dev` (development)
- `npm run build`
- `npm run export` (generate static `out/` folder)

Notes:
- Node 18+ recommended.
- Next.js 14 was used in package.json; adjust versions as needed.
