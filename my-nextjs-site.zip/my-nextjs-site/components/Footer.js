export default function Footer() {
  return (
    <footer style={{textAlign: 'center', padding: '20px', background: '#eee'}}>
      <p>&copy; 2025 My Website</p>
    </footer>
  );
}
