import Link from 'next/link';
export default function Header() {
  return (
    <header style={{background: '#3498db', padding: '15px 0'}}>
      <nav>
        <ul style={{display: 'flex', justifyContent: 'center', listStyle: 'none'}}>
          <li style={{margin: '0 20px'}}><Link href="/">Home</Link></li>
          <li style={{margin: '0 20px'}}><Link href="/blog">Blog</Link></li>
          <li style={{margin: '0 20px'}}><Link href="/tools">Tools</Link></li>
          <li style={{margin: '0 20px'}}><Link href="/profile">Profile</Link></li>
          <li style={{margin: '0 20px'}}><Link href="/admin">Admin</Link></li>
        </ul>
      </nav>
    </header>
  );
}
