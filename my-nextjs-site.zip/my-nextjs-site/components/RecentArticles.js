import Link from 'next/link';
export default function RecentArticles() {
  const articles = [
    {title: 'Post 1', slug: 'post1'},
    {title: 'Post 2', slug: 'post2'},
    {title: 'Post 3', slug: 'post3'},
  ];

  return (
    <div>
      <h2>Recent Articles</h2>
      <ul>
        {articles.map(a => (
          <li key={a.slug}>
            <Link href={`/blog/${a.slug}`}>{a.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
