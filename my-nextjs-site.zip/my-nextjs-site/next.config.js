/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'export' // allows `next export` to create static HTML in out/
}
module.exports = nextConfig;
