import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Link from 'next/link';

export default function Admin() {
  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>Admin Panel</h1>
        <ul>
          <li><Link href="/admin/manage_posts">Manage Posts</Link></li>
          <li><Link href="/admin/manage_tools">Manage Tools</Link></li>
        </ul>
      </main>
      <Footer />
    </>
  );
}
