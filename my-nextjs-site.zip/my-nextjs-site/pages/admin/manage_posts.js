import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function ManagePosts() {
  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>Manage Blog Posts</h1>
        <p>Add/Edit/Delete posts here.</p>
      </main>
      <Footer />
    </>
  );
}
