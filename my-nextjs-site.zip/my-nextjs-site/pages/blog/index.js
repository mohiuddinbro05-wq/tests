import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Link from 'next/link';

export default function Blog() {
  const posts = [
    {title: 'Post 1', slug: 'post1'},
    {title: 'Post 2', slug: 'post2'},
    {title: 'Post 3', slug: 'post3'},
  ];

  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>All Blog Posts</h1>
        <ul>
          {posts.map(p => (
            <li key={p.slug}>
              <Link href={`/blog/${p.slug}`}>{p.title}</Link>
            </li>
          ))}
        </ul>
      </main>
      <Footer />
    </>
  );
}
