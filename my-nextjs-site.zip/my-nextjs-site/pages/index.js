import Header from '../components/Header';
import Footer from '../components/Footer';
import RecentArticles from '../components/RecentArticles';

export default function Home() {
  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>Welcome to My Website</h1>
        <p>Website features and details will appear here.</p>
        <RecentArticles />
      </main>
      <Footer />
    </>
  );
}
