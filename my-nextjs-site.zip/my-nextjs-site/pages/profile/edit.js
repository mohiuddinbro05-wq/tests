import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function EditProfile() {
  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>Edit Profile</h1>
        <p>Edit form will appear here.</p>
      </main>
      <Footer />
    </>
  );
}
