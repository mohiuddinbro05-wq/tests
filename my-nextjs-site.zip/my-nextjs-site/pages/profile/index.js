import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Profile() {
  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>User Profile</h1>
        <p>Profile details will appear here.</p>
      </main>
      <Footer />
    </>
  );
}
