import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Link from 'next/link';

export default function Tools() {
  const tools = [
    {name: 'Tool 1', slug: 'tool1'},
    {name: 'Tool 2', slug: 'tool2'},
    {name: 'Tool 3', slug: 'tool3'},
  ];

  return (
    <>
      <Header />
      <main style={{textAlign: 'center', padding: '50px'}}>
        <h1>All Tools</h1>
        <ul>
          {tools.map(t => (
            <li key={t.slug}>
              <Link href={`/tools/${t.slug}`}>{t.name}</Link>
            </li>
          ))}
        </ul>
      </main>
      <Footer />
    </>
  );
}
