export function formatDate(d){ return new Date(d).toLocaleDateString(); }
